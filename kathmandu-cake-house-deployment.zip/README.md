# Kathmandu Cake House

This folder contains the current Kathmandu Cake House website prepared for static hosting.

## Deploy
1. Upload `index.html` to a GitHub repository.
2. Make sure the file is named exactly `index.html`.
3. Enable GitHub Pages from Settings → Pages.
4. Choose the `main` branch and `/ (root)` folder.

## Important
The current checkout UI is frontend-only. A real order database, payment gateway,
customer authentication, and admin order management still need a backend integration.
